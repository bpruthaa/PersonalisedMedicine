import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout, LeakyReLU, BatchNormalization
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.regularizers import l2
from tensorflow.keras.utils import to_categorical
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.utils.class_weight import compute_class_weight
from imblearn.over_sampling import SMOTE

# Step 1: Data Preprocessing
df = pd.read_csv(r'E:\College Project3\Output2\cleaned_data.csv')  # Load dataset
print(df.columns)

# Rename columns
df.rename(columns={
    'Heart Rate (bpm)': 'Heart Rate',
    'Blood Pressure (mm Hg)': 'Blood Pressure',
    'Oxygen Saturation (%)': 'Oxygen Saturation',
    'Respiratory Rate (bpm)': 'Respiratory Rate',
    'Temperature (°C)': 'Temperature',
    'Hemoglobin (g/dL)': 'Hemoglobin',
    'WBC (cells/μL)': 'WBC',
    'Creatinine (mg/dL)': 'Creatinine',
    'Bicarbonate (mEq/L)': 'Bicarbonate',
    'Lactate (mmol/L)': 'Lactate',
    'Cognitive Score (MMSE)': 'Cognitive Score'
}, inplace=True)

# Feature list
features = [
    'Age', 'Gender', 'Heart Rate', 'Blood Pressure', 'Oxygen Saturation',
    'Respiratory Rate', 'Temperature', 'Hemoglobin', 'WBC', 'Creatinine',
    'Bicarbonate', 'Lactate', 'Cognitive Score', 'Disease Severity'
]

# Target: Assuming we have a column named 'Mental Health Outcome' in the dataset (like Stress, Anxiety, or Depression level)
target = 'Mental Health Outcome'

# Ensure target exists (dummy target if not)
if target not in df.columns:
    df[target] = np.random.choice(['Low', 'Moderate', 'High'], size=len(df))

# Map mental health outcomes to numeric values (0 = Low, 1 = Moderate, 2 = High)
outcome_mapping = {
    'Low': 0,
    'Moderate': 1,
    'High': 2
}
df[target] = df[target].map(outcome_mapping)

# One-hot encode categorical variables
df = pd.get_dummies(df, columns=['Ethnicity', 'Medication Name'], drop_first=True)

# Scale numerical features
scaler = StandardScaler()
df[features] = scaler.fit_transform(df[features])

# Convert target variable to one-hot encoding for multi-class classification
y = to_categorical(df[target])

# Feature matrix
X = df[features].values

# Step 2: Split Data
X_train, X_test, y_train, y_test, train_idx, test_idx = train_test_split(
    X, y, df.index, test_size=0.2, random_state=42
)

# Step 3: Handle Class Imbalance with SMOTE
smote = SMOTE(sampling_strategy='auto', random_state=42)
X_train_smote, y_train_smote = smote.fit_resample(X_train, y_train)

# Step 4: Calculate class weights to handle class imbalance
class_weights = compute_class_weight('balanced', classes=np.unique(df[target]), y=df[target])
class_weights = dict(zip(np.unique(df[target]), class_weights))

# Build the Neural Network Model
model = Sequential()

# Input layer
model.add(Dense(256, input_dim=X_train.shape[1], kernel_initializer='he_normal', kernel_regularizer=l2(0.001)))
model.add(LeakyReLU(alpha=0.1))
model.add(BatchNormalization())
model.add(Dropout(0.5))  # Increased dropout for regularization

# Hidden layers
model.add(Dense(128, kernel_initializer='he_normal', kernel_regularizer=l2(0.001)))
model.add(LeakyReLU(alpha=0.1))
model.add(BatchNormalization())
model.add(Dropout(0.5))

model.add(Dense(64, kernel_initializer='he_normal', kernel_regularizer=l2(0.001)))
model.add(LeakyReLU(alpha=0.1))
model.add(Dropout(0.4))

# Output layer (3 classes for Mental Health: Low, Moderate, High)
model.add(Dense(3, activation='softmax'))

# Compile model
optimizer = Adam(learning_rate=0.001)
model.compile(optimizer=optimizer, loss='categorical_crossentropy', metrics=['accuracy'])

# Early stopping to prevent overfitting
early_stopping = EarlyStopping(monitor='val_loss', patience=25, restore_best_weights=True)

# Reduce learning rate if validation loss does not improve
lr_scheduler = ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=10, min_lr=0.0001)

# Train the model
history = model.fit(
    X_train_smote, y_train_smote, epochs=500, batch_size=64,
    validation_data=(X_test, y_test),
    class_weight=class_weights, callbacks=[early_stopping, lr_scheduler]
)

# Step 5: Evaluate the model
loss, accuracy = model.evaluate(X_test, y_test)
print(f'Test Loss: {loss}, Test Accuracy: {accuracy}')

# Step 6: Predictions
predictions = model.predict(X)
predicted_classes = np.argmax(predictions, axis=1)

# Add predictions to the dataframe
df['Predicted Mental Health Outcome'] = predicted_classes

# Reverse mapping of class indices back to outcome names
inverse_outcome_mapping = {v: k for k, v in outcome_mapping.items()}
df['Predicted Mental Health Outcome'] = df['Predicted Mental Health Outcome'].map(inverse_outcome_mapping)

# Step 7: Save predicted outcomes in the original dataset copy
original_df = pd.read_csv(r'E:\College Project3\Output2\cleaned_data.csv')  # Load original dataset
# Make a copy to avoid modifying the original file
df_copy = original_df.copy()

# Add predicted outcomes to the copy of the original dataset
df_copy['Predicted Mental Health Outcome'] = df['Predicted Mental Health Outcome']

# Save the dataset with predictions
df_copy.to_csv(r'E:\College Project3\Output2\cleaned_data_with_pyschlogical_predictions.csv', index=False)

# Save the trained model
model.save(r'E:\College Project3\Output2\mental_health_model.h5')  # Save the trained model in HDF5 format

# Step 8: Additional Evaluation Metrics
print(classification_report(np.argmax(y, axis=1), predicted_classes))
print(confusion_matrix(np.argmax(y, axis=1), predicted_classes))
