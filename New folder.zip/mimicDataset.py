import pandas as pd
import numpy as np

# Set random seed for reproducibility
np.random.seed(5000)

# Number of synthetic patients
num_patients = 5000

# Generate synthetic data
data = {
    # Demographics
    "Patient ID": [f"P{str(i).zfill(5)}" for i in range(1, num_patients + 1)],
    "Age": np.random.randint(40, 80, size=num_patients),
    "Gender": np.random.choice(['M', 'F'], size=num_patients),
    "Ethnicity": np.random.choice(['Caucasian', 'Hispanic', 'Asian', 'Black'], size=num_patients),

    # Vital Signs
    "Heart Rate (bpm)": np.random.randint(60, 120, size=num_patients),
    "Blood Pressure (mm Hg)": [f"{np.random.randint(100, 140)}/{np.random.randint(60, 90)}" for _ in range(num_patients)],
    "Oxygen Saturation (%)": np.random.randint(90, 100, size=num_patients),
    "Respiratory Rate (bpm)": np.random.randint(12, 20, size=num_patients),  # Normal range for adults
    "Temperature (°C)": np.random.uniform(36.5, 38.5, size=num_patients),

    # Laboratory Test Results
    "Hemoglobin (g/dL)": np.random.uniform(11.0, 15.5, size=num_patients),
    "WBC (cells/μL)": np.random.randint(4000, 12000, size=num_patients),
    "Creatinine (mg/dL)": np.random.uniform(0.5, 1.5, size=num_patients),
    "Bicarbonate (mEq/L)": np.random.uniform(22, 28, size=num_patients),
    "Lactate (mmol/L)": np.random.uniform(0.5, 2.0, size=num_patients),  # Elevated in sepsis

    # Medications
    "Medication Name": np.random.choice(['Furosemide', 'Lisinopril', 'Vancomycin', 'Albuterol', 'Metformin'], size=num_patients),
    "Medication Dosage": np.random.choice(['40 mg', '10 mg', '1 gm', '5 mg', '500 mg'], size=num_patients),
    "Medication Route": np.random.choice(['IV', 'Oral', 'Inhaled'], size=num_patients),
    "Time of Medication": pd.date_range('2024-11-25', periods=num_patients, freq='H').strftime('%Y-%m-%d %H:%M').tolist(),

    # ICD-9 Diagnosis Codes
    "Primary Diagnosis (ICD-9)": np.random.choice(['410.91 (MI)', '428.0 (Heart Failure)', '997.09 (Sepsis)', '491.21 (COPD Exacerbation)', '250.00 (Diabetes)'], size=num_patients),
    "Secondary Diagnosis (ICD-9)": np.random.choice(['E11.9 (Type 2 Diabetes)', 'I21.9 (Acute MI)', 'J44.9 (COPD)', 'K70.0 (Alcoholic liver disease)', 'M54.5 (Low back pain)'], size=num_patients),

    # Clinical Notes
    "Physician Notes": ["Patient is stable and recovering." for _ in range(num_patients)],  # Simplified for the example
    "Nurse Notes": ["Patient is responding well to treatment." for _ in range(num_patients)],
    "Radiology Reports": ["Chest X-ray shows mild consolidation." for _ in range(num_patients)],

    # ICU Data
    "Ventilator Usage": np.random.choice(['Yes', 'No'], size=num_patients),
    "Dialysis Required": np.random.choice(['Yes', 'No'], size=num_patients),
    "ICU Stay Duration (days)": np.random.randint(1, 10, size=num_patients),

    # Severity Scores
    "APACHE II Score": np.random.randint(10, 20, size=num_patients),
    "SAPS II Score": np.random.randint(20, 40, size=num_patients),
    "SOFA Score": np.random.randint(3, 9, size=num_patients),

    # Time-Series Data (simulated)
    "Vitals Time-Series (Heart Rate)": [np.random.randint(60, 120, size=5).tolist() for _ in range(num_patients)],
    "Vitals Time-Series (Blood Pressure)": [f"{np.random.randint(100, 140)}/{np.random.randint(60, 90)}" for _ in range(num_patients)],
    "Vitals Time-Series (Oxygen Saturation)": [np.random.randint(90, 100, size=5).tolist() for _ in range(num_patients)],

    # Mortality and Outcome Data
    "Mortality (Hospital Mortality)": np.random.choice(['Yes', 'No'], size=num_patients),
    "Readmission Risk": np.random.choice(['Low', 'Medium', 'High'], size=num_patients),

    # Sepsis Detection and Infection Monitoring
    "Sepsis Risk": np.random.choice(['Low', 'Moderate', 'High'], size=num_patients),
    "Infection Status": np.random.choice(['None', 'Suspected', 'Confirmed'], size=num_patients),
}

# Convert to DataFrame
df = pd.DataFrame(data)

# Specify the full path to save the CSV file, including the file name
df.to_csv(r'E:\New folder\synthetic_patient_data.csv', index=False)

# Display a success message
print("Dataset has been successfully saved to 'synthetic_patient_data.csv'.")