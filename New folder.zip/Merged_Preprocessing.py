import pandas as pd
from sklearn.impute import SimpleImputer

# Load your dataset (replace with your actual path if needed)
df = pd.read_csv(r'E:\New folder\Output\combined_patient_data.csv')  # Update the path as per your file location

# Step 1: Remove unrequired columns (those based on your previous instructions)
columns_to_drop = [
    'MRI Scan Available', 
    'fMRI Scan Available', 
    'EEG Data Available', 
    'Condition-specific Info', 
    'APACHE II Score', 
    'SAPS II Score', 
    'SOFA Score',
    'Dialysis Required',
    'Vitals Time-Series (Heart Rate)',
    'Vitals Time-Series (Blood Pressure)',
    'Vitals Time-Series (Oxygen Saturation)',
    'Medication',
    'Medication Dosage',   
]
df.drop(columns=columns_to_drop, inplace=True)

# Remove the 'Clinical Outcome' column
df.drop(columns=['Clinical Outcome'], inplace=True)

# Step 2: Identify numerical and categorical columns
numerical_columns = df.select_dtypes(include=['float64', 'int64']).columns
categorical_columns = df.select_dtypes(include=['object']).columns

# Step 3: Fill missing values for numerical columns using SimpleImputer (mean or median)
numerical_imputer = SimpleImputer(strategy='mean')  # You can change 'mean' to 'median' or 'constant'
df[numerical_columns] = numerical_imputer.fit_transform(df[numerical_columns])

# Step 4: Fill missing values for categorical columns using SimpleImputer (most frequent or constant)
categorical_imputer = SimpleImputer(strategy='most_frequent')  # Use 'constant' if you need a specific value like 'Unknown'
df[categorical_columns] = categorical_imputer.fit_transform(df[categorical_columns])

# Optional: Specifically fill 'Medication Name' with 'Unknown' if needed
df['Medication Name'].fillna('Unknown', inplace=True)

# Step 5: Verify if there are still any missing values
missing_values = df.isnull().sum()

# Print the count of missing values in each column
print("Missing values after imputation:")
print(missing_values[missing_values > 0])

# If there are no missing values, you will see an empty output
# At this point, your dataframe `df` should have no missing values

# Optional: Save the cleaned dataframe to a new file
df.to_csv(r'E:\New folder\Output\cleaned_data.csv', index=False)

# Display the cleaned dataframe (optional)
print(df.head())
