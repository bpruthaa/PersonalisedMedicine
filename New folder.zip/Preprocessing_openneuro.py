import pandas as pd
from sklearn.preprocessing import MinMaxScaler

# Read the original CSV file
df = pd.read_csv(r'E:\New folder\Output\synthetic_neuroimaging_clinical_data.csv')

# 1. Gender conversion to 0 for Male and 1 for Female
df['Gender'] = df['Gender'].map({'M': 0, 'F': 1})

# 2. Ethnicity conversion to 0 for Asian, 1 for Black, 2 for Caucasian, 3 for Hispanic
ethnicity_map = {'Asian': 0, 'Black': 1, 'Caucasian': 2, 'Hispanic': 3}
df['Ethnicity'] = df['Ethnicity'].map(ethnicity_map)

# 3. Convert 'Yes' to 1 and 'No' to 0 for MRI Scan, fMRI Scan, EEG Data
df['MRI Scan Available'] = df['MRI Scan Available'].map({'Yes': 1, 'No': 0})
df['fMRI Scan Available'] = df['fMRI Scan Available'].map({'Yes': 1, 'No': 0})
df['EEG Data Available'] = df['EEG Data Available'].map({'Yes': 1, 'No': 0})

# 4. Normalize the Cognitive Score (MMSE)
scaler = MinMaxScaler()
df['Cognitive Score (MMSE)'] = scaler.fit_transform(df[['Cognitive Score (MMSE)']])

# 5. Convert categorical columns to numerical values (for the required columns)
medication_map = {'No Medication': 0, 'Lisinopril': 1, 'Alprazolam': 2, 'Metformin': 3, 'Donepezil': 4, 'Other': 5}
df['Medication'] = df['Medication'].map(medication_map)

# For medication dosage, clinical diagnosis, disease severity, condition info, and outcome, we map them similarly
med_dosage_map = {'None': 0, '5 mg': 1, '10 mg': 2, '500 mg': 3, '1 gm': 4}
df['Medication Dosage'] = df['Medication Dosage'].map(med_dosage_map)

diagnosis_map = {
    "Alzheimer's Disease": 0, 'Depression': 1, 'Parkinson\'s Disease': 2, 'Schizophrenia': 3, 'Healthy': 4
}
df['Clinical Diagnosis'] = df['Clinical Diagnosis'].map(diagnosis_map)

severity_map = {'Severe': 0, 'Moderate': 1, 'Mild': 2, 'Stable': 3}
df['Disease Severity'] = df['Disease Severity'].map(severity_map)

condition_info_map = {'Early stage': 0, 'Mid stage': 1, 'Late stage': 2, 'Stable': 3}
df['Condition-specific Info'] = df['Condition-specific Info'].map(condition_info_map)

outcome_map = {'Recovered': 0, 'Worsened': 1, 'Improved': 2, 'Stable': 3}
df['Clinical Outcome'] = df['Clinical Outcome'].map(outcome_map)

# 6. Drop unnecessary columns, but keep Patient ID
df = df.drop(columns=['Age', 'Hospitalized'])

# Show the preprocessed data
print(df.head())

# Save the preprocessed DataFrame to a CSV file
df.to_csv(r'E:\New folder\Output\preprocessed_synthetic_neuroimaging_clinical_data.csv', index=False)
