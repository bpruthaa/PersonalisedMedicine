import pandas as pd

# Load the two datasets
df_clinical = pd.read_csv(r'E:\New folder\Output\preprocessed_synthetic_patient_data.csv')  # Replace with the path to your clinical dataset
df_neuroimaging = pd.read_csv(r'E:\New folder\Output\preprocessed_synthetic_neuroimaging_clinical_data.csv')  # Replace with the path to your neuroimaging dataset

# Merge the datasets on 'Patient ID', 'Gender', and 'Ethnicity'
df_combined = pd.merge(df_clinical, df_neuroimaging, on=['Patient ID', 'Gender', 'Ethnicity'], how='inner')

# Define the column order as requested
columns_order = [
    'Patient ID', 'Age', 'Gender', 'Ethnicity', 'Heart Rate (bpm)', 'Blood Pressure (mm Hg)', 
    'Oxygen Saturation (%)', 'Respiratory Rate (bpm)', 'Temperature (°C)', 'Hemoglobin (g/dL)', 
    'WBC (cells/μL)', 'Creatinine (mg/dL)', 'Bicarbonate (mEq/L)', 'Lactate (mmol/L)', 
    'Medication Name', 'Dialysis Required', 'APACHE II Score', 'SAPS II Score', 'SOFA Score',
    'Vitals Time-Series (Heart Rate)', 'Vitals Time-Series (Blood Pressure)', 'Vitals Time-Series (Oxygen Saturation)', 
    'MRI Scan Available', 'fMRI Scan Available', 'EEG Data Available', 'Medication', 'Medication Dosage',
    'Cognitive Score (MMSE)', 'Clinical Diagnosis', 'Disease Severity', 'Condition-specific Info', 'Clinical Outcome'
]

# Reorder the columns in the combined dataset
df_combined = df_combined[columns_order]

# Save the combined dataset to a new CSV file
df_combined.to_csv(r'E:\New folder\Output\combined_patient_data.csv', index=False)

# Display the first few rows of the combined dataset
print(df_combined.head())
