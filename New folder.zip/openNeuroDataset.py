import pandas as pd
import numpy as np

# Set random seed for reproducibility
np.random.seed(42)

# Number of synthetic patients
num_patients = 5000

# Generate synthetic data
data = {
    # Demographics
    "Patient ID": [f"P{str(i).zfill(5)}" for i in range(1, num_patients + 1)],
    "Age": np.random.randint(50, 80, size=num_patients),
    "Gender": np.random.choice(['M', 'F'], size=num_patients),
    "Ethnicity": np.random.choice(['Caucasian', 'Hispanic', 'Asian', 'Black'], size=num_patients),

    # Neuroimaging Data
    "MRI Scan Available": np.random.choice(['Yes', 'No'], size=num_patients),
    "fMRI Scan Available": np.random.choice(['Yes', 'No'], size=num_patients),
    "EEG Data Available": np.random.choice(['Yes', 'No'], size=num_patients),

    # Behavioral and Clinical Data
    "Medication": np.random.choice(['Donepezil', 'Lisinopril', 'Alprazolam', 'Metformin', 'No Medication'], size=num_patients),
    "Medication Dosage": np.random.choice(['10 mg', '5 mg', '1 gm', '500 mg', 'None'], size=num_patients),
    
    # Cognitive and Clinical Assessments
    "Cognitive Score (MMSE)": np.random.randint(20, 30, size=num_patients),  # Mini-Mental State Examination score
    "Clinical Diagnosis": np.random.choice(['Alzheimer\'s Disease', 'Schizophrenia', 'Depression', 'Healthy', 'Parkinson\'s Disease'], size=num_patients),
    "Disease Severity": np.random.choice(['Mild', 'Moderate', 'Severe'], size=num_patients),

    # Disease or Condition-Specific Information
    "Condition-specific Info": np.random.choice(['Early stage', 'Mid stage', 'Late stage', 'Stable', 'Improved'], size=num_patients),

    # Clinical Outcomes and Treatment Responses
    "Clinical Outcome": np.random.choice(['Improved', 'Stable', 'Worsened', 'Recovered'], size=num_patients),
    "Hospitalized": np.random.choice(['Yes', 'No'], size=num_patients),
}

# Convert to DataFrame
df = pd.DataFrame(data)

# Display the first few rows of the generated dataset
print(df.head())

# Save to CSV
df.to_csv(r'E:\New folder\synthetic_patient_data.csv', index=False)
