import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.model_selection import train_test_split
from tensorflow.keras.utils import to_categorical
from sklearn.compose import ColumnTransformer
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Dense, Dropout
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.regularizers import l2
from tensorflow.keras.callbacks import EarlyStopping
from sklearn.metrics import classification_report, confusion_matrix
import os

# Step 1: Load the original dataset
df = pd.read_csv(r'E:\College Project3\cleaned_data.csv')

# Check columns to ensure target columns are present
print("Dataset columns:", df.columns)

# If target columns don't exist, create placeholder columns for testing
if 'Health Condition' not in df.columns or 'Psychological Condition' not in df.columns:
    print("Target columns are missing. Creating them...")
    df['Health Condition'] = [1] * len(df)  # Placeholder for actual health condition logic
    df['Psychological Condition'] = [1] * len(df)  # Placeholder for actual psychological condition logic

# Define columns
feature_columns = ['Age', 'Gender', 'Ethnicity', 'Heart Rate (bpm)', 'Blood Pressure (mm Hg)', 
                   'Oxygen Saturation (%)', 'Respiratory Rate (bpm)', 'Temperature (°C)', 
                   'Hemoglobin (g/dL)', 'WBC (cells/μL)', 'Creatinine (mg/dL)', 'Bicarbonate (mEq/L)', 
                   'Lactate (mmol/L)', 'Cognitive Score (MMSE)', 'Clinical Diagnosis', 'Disease Severity']
target_columns = ['Health Condition', 'Psychological Condition']

# Step 2: Data Preprocessing
# Categorical columns are the ones with string values or categories
categorical_cols = ['Gender', 'Ethnicity', 'Clinical Diagnosis', 'Disease Severity']

# Numeric columns should include only the ones that are continuous measurements
numeric_cols = [col for col in feature_columns if col not in categorical_cols]

# Create a preprocessor that scales numeric features and one-hot encodes categorical features
preprocessor = ColumnTransformer(
    transformers=[ 
        ('num', StandardScaler(), numeric_cols),  # Numeric columns: standard scaling
        ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_cols)  # Categorical columns: one-hot encoding
    ])

# Separate features (X) and targets (y)
X = df[feature_columns]
y = df[target_columns]

# Step 3: Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Apply preprocessing to training and testing data
X_train = preprocessor.fit_transform(X_train)
X_test = preprocessor.transform(X_test)

# Encode the target variables as categorical (one-hot encoding)
y_train_health = to_categorical(y_train['Health Condition'], num_classes=4)  # One-hot encoding for Health Condition
y_test_health = to_categorical(y_test['Health Condition'], num_classes=4)

y_train_psych = to_categorical(y_train['Psychological Condition'], num_classes=4)  # One-hot encoding for Psychological Condition
y_test_psych = to_categorical(y_test['Psychological Condition'], num_classes=4)

# Step 4: Build the Neural Network Model
input_dim = X_train.shape[1]

input_layer = Input(shape=(input_dim,))
x = Dense(32, activation='relu', kernel_regularizer=l2(0.01))(input_layer)  # L2 Regularization
x = Dropout(0.3)(x)  # Dropout to prevent overfitting
x = Dense(16, activation='relu', kernel_regularizer=l2(0.01))(x)  # L2 Regularization

# Output layers for Health Condition and Psychological Condition
health_condition_output = Dense(4, activation='softmax', name='Health_Condition')(x)
psychological_condition_output = Dense(4, activation='softmax', name='Psychological_Condition')(x)

# Create the model
model = Model(inputs=input_layer, outputs=[health_condition_output, psychological_condition_output])

# Compile the model with metrics for each output
model.compile(optimizer=Adam(learning_rate=0.0001),  # Reduced learning rate
              loss={'Health_Condition': 'categorical_crossentropy', 
                    'Psychological_Condition': 'categorical_crossentropy'},
              metrics={'Health_Condition': ['accuracy'], 
                       'Psychological_Condition': ['accuracy']})

# Step 5: Handle Class Imbalance for each output separately
class_weights_health = {0: 1, 1: 1, 2: 10, 3: 10}  # Example class weights, modify as per your data distribution
class_weights_psych = {0: 1, 1: 1, 2: 10, 3: 10}  # Modify class weights for Psychological Condition similarly

# Step 6: Early Stopping to prevent overfitting
early_stopping = EarlyStopping(monitor='val_loss', patience=20, restore_best_weights=True)

# Step 7: Train the model
history = model.fit(X_train,
                    {'Health_Condition': y_train_health, 'Psychological_Condition': y_train_psych},
                    epochs=200, 
                    batch_size=32, 
                    validation_data=(X_test, {'Health_Condition': y_test_health, 'Psychological_Condition': y_test_psych}),
                    callbacks=[early_stopping],
                    class_weight={'Health_Condition': class_weights_health, 
                                  'Psychological_Condition': class_weights_psych})

# Step 8: Save the trained model
model.save('health_psychological_condition_model.h5')
print("Model saved successfully!")

# Step 9: Evaluate the model
loss, health_loss, psych_loss, health_accuracy, psych_accuracy = model.evaluate(
    X_test,
    {'Health_Condition': y_test_health, 'Psychological_Condition': y_test_psych}
)

# Print the results
print(f'Health Condition Loss: {health_loss}')
print(f'Psychological Condition Loss: {psych_loss}')
print(f'Health Condition Accuracy: {health_accuracy}')
print(f'Psychological Condition Accuracy: {psych_accuracy}')

# Evaluate with confusion matrix and classification report
y_pred_health = model.predict(X_test)[0].argmax(axis=1)
y_pred_psych = model.predict(X_test)[1].argmax(axis=1)

print("\nHealth Condition Classification Report:")
print(classification_report(y_test['Health Condition'], y_pred_health))

print("\nPsychological Condition Classification Report:")
print(classification_report(y_test['Psychological Condition'], y_pred_psych))

print("\nHealth Condition Confusion Matrix:")
print(confusion_matrix(y_test['Health Condition'], y_pred_health))

print("\nPsychological Condition Confusion Matrix:")
print(confusion_matrix(y_test['Psychological Condition'], y_pred_psych))

# Step 10: Check if new data exists, if not, create it
new_data_path = r'E:\College Project3\new_patient_data.csv'

# Create synthetic data if the file doesn't exist
if not os.path.exists(new_data_path):
    print(f"New data file not found. Creating synthetic data at {new_data_path}...")

    # Create synthetic data with 5000 rows
    np.random.seed(42)
    new_data = pd.DataFrame({
        'Age': np.random.randint(18, 90, size=5000),
        'Gender': np.random.choice(['Male', 'Female'], size=5000),
        'Ethnicity': np.random.choice(['Caucasian', 'African American', 'Asian', 'Hispanic'], size=5000),
        'Heart Rate (bpm)': np.random.randint(60, 100, size=5000),
        'Blood Pressure (mm Hg)': np.random.randint(110, 180, size=5000),
        'Oxygen Saturation (%)': np.random.randint(90, 100, size=5000),
        'Respiratory Rate (bpm)': np.random.randint(12, 20, size=5000),
        'Temperature (°C)': np.random.uniform(36.5, 37.5, size=5000),
        'Hemoglobin (g/dL)': np.random.uniform(12, 18, size=5000),
        'WBC (cells/μL)': np.random.randint(4000, 11000, size=5000),
        'Creatinine (mg/dL)': np.random.uniform(0.6, 1.2, size=5000),
        'Bicarbonate (mEq/L)': np.random.uniform(22, 28, size=5000),
        'Lactate (mmol/L)': np.random.uniform(0.5, 2.0, size=5000),
        'Cognitive Score (MMSE)': np.random.randint(18, 30, size=5000),
        'Clinical Diagnosis': np.random.choice(['Healthy', 'Hypertension', 'Diabetes', 'COPD'], size=5000),
        'Disease Severity': np.random.choice(['Mild', 'Moderate', 'Severe'], size=5000)
    })

    # Save the new data to CSV
    new_data.to_csv(new_data_path, index=False)
    print(f"New patient data with 5000 rows created and saved at {new_data_path}")

# Step 11: Load the new data
new_data = pd.read_csv(new_data_path)

# Preprocess the new data (same preprocessing as the training data)
new_data_transformed = preprocessor.transform(new_data[feature_columns])

# Predict health and psychological conditions for the new data
predictions = model.predict(new_data_transformed)

# Extract predicted class for Health Condition and Psychological Condition
health_condition_pred = predictions[0].argmax(axis=1)  # Get the index of the highest probability for Health Condition
psychological_condition_pred = predictions[1].argmax(axis=1)  # Get the index of the highest probability for Psychological Condition

# Add the predicted columns back to the new data
new_data['Health Condition'] = health_condition_pred + 1  # Adding 1 to match the 1-based index (1, 2, 3, 4)
new_data['Psychological Condition'] = psychological_condition_pred + 1  # Same as above

# Step 12: Save the New Dataset with Predictions
new_data.to_csv(r'E:\College Project3\new_patient_data_with_predictions.csv', index=False)
print("New dataset with predictions saved as 'new_patient_data_with_predictions.csv'")
