import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler

# Load the synthetic dataset
df = pd.read_csv(r'E:\New folder\Output\synthetic_patient_data.csv')

# 1. Convert 'Gender' into 0 for Male and 1 for Female
df['Gender'] = df['Gender'].apply(lambda x: 0 if x == 'M' else 1)

# 2. Convert 'Ethnicity' into numerical categories
ethnicity_map = {
    'Asian': 0,
    'Black': 1,
    'Caucasian': 2,
    'Hispanic': 3
}
df['Ethnicity'] = df['Ethnicity'].map(ethnicity_map)

# 3. Normalize the specified columns (Min-Max scaling)
columns_to_normalize = [
    'Heart Rate (bpm)', 
    'Oxygen Saturation (%)', 
    'Respiratory Rate (bpm)', 
    'Temperature (°C)', 
    'Hemoglobin (g/dL)', 
    'WBC (cells/μL)', 
    'Creatinine (mg/dL)', 
    'Bicarbonate (mEq/L)', 
    'Lactate (mmol/L)', 
    'Vitals Time-Series (Heart Rate)', 
    'Vitals Time-Series (Oxygen Saturation)', 
    'APACHE II Score', 
    'SAPS II Score', 
    'SOFA Score'
]

# Initialize the MinMaxScaler
scaler = MinMaxScaler()

# 4. Blood Pressure Processing (Parse, average, and normalize)
# Parse and compute the average of systolic/diastolic blood pressure
df['Vitals Time-Series (Blood Pressure)'] = df['Vitals Time-Series (Blood Pressure)'].apply(
    lambda x: np.mean([int(i) for i in x.split('/')]) if isinstance(x, str) else np.nan  # Handle cases where value is not a valid string
)

# Normalize the 'Vitals Time-Series (Blood Pressure)' after averaging the systolic/diastolic
df['Vitals Time-Series (Blood Pressure)'] = scaler.fit_transform(df[['Vitals Time-Series (Blood Pressure)']])

df['Blood Pressure (mm Hg)'] = df['Blood Pressure (mm Hg)'].apply(
    lambda x: np.mean([int(i) for i in x.split('/')]) if isinstance(x, str) and '/' in x else np.nan  # Handle cases where value is not valid or format is wrong
)
   
# Normalize the 'Blood Pressure (mm Hg)' after averaging the systolic/diastolic
df['Blood Pressure (mm Hg)'] = scaler.fit_transform(df[['Blood Pressure (mm Hg)']])

# Normalize all other specified columns
for col in columns_to_normalize:
    if col == 'Vitals Time-Series (Heart Rate)':  # Normalize Vitals Time-Series (Heart Rate)
        df['Vitals Time-Series (Heart Rate)'] = df['Vitals Time-Series (Heart Rate)'].apply(
            lambda x: np.min(eval(x))  # Extract minimum value from the array and normalize
        )
    elif col == 'Vitals Time-Series (Oxygen Saturation)':  # Normalize Vitals Time-Series (Oxygen Saturation)
        df['Vitals Time-Series (Oxygen Saturation)'] = df['Vitals Time-Series (Oxygen Saturation)'].apply(
            lambda x: np.min(eval(x))  # Extract minimum value from the array and normalize
        )
    
    # Apply Min-Max Scaling for the column
    df[col] = scaler.fit_transform(df[[col]])

# 5. Convert 'Dialysis Required' to 0 and 1 (Yes -> 1, No -> 0)
df['Dialysis Required'] = df['Dialysis Required'].apply(lambda x: 1 if x == 'Yes' else 0)

# 6. Drop the unnecessary columns
columns_to_drop = [
    'Time of Medication', 'Physician Notes', 'Nurse Notes', 
    'Radiology Reports', 'Ventilator Usage', 'ICU Stay Duration (days)', 
    'Mortality (Hospital Mortality)', 'Readmission Risk', 'Sepsis Risk', 
    'Infection Status', 'Medication Dosage', 'Medication Route', 
    'Primary Diagnosis (ICD-9)', 'Secondary Diagnosis (ICD-9)'
]
df.drop(columns=columns_to_drop, inplace=True)

# 7. Save the preprocessed dataset to a new CSV file
df.to_csv(r'E:\New folder\Output\preprocessed_synthetic_patient_data.csv', index=False)

# Display the first few rows of the preprocessed data
print(df.head())
